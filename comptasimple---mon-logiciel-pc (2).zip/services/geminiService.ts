
import { GoogleGenAI } from "@google/genai";
import { Invoice, Expense, QuarterlySummary } from "../types";

export const analyzeFinances = async (invoices: Invoice[], expenses: Expense[], summary: QuarterlySummary) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const prompt = `
    Agis en tant qu'expert comptable pour une petite entreprise au Québec, Canada.
    Analyse les données financières suivantes pour le trimestre ${summary.quarter} de l'année ${summary.year}:
    - Revenu Total (HT): ${summary.revenueHT}$
    - TPS Collectée: ${summary.tpsCollected}$
    - TVQ Collectée: ${summary.tvqCollected}$
    - Dépenses Totales (HT): ${summary.expensesHT}$
    - TPS Payée sur dépenses (ITC): ${summary.tpsPaid}$
    - TVQ Payée sur dépenses (ITR): ${summary.tvqPaid}$
    - Bénéfice net: ${summary.netIncome}$
    - Répartition des dépenses: ${JSON.stringify(summary.expensesByCategory)}

    Donne un résumé court (3-4 phrases) de la santé financière. 
    Mentionne spécifiquement les montants nets de taxes à remettre au gouvernement (TPS et TVQ).
    Donne un conseil stratégique simple adapté au marché québécois.
    Réponds en français.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });
    return response.text;
  } catch (error) {
    console.error("Erreur lors de l'analyse Gemini:", error);
    return "Impossible de générer l'analyse pour le moment.";
  }
};
