
import React, { useState, useEffect } from 'react';
import { View } from '../types';

interface SidebarProps {
  currentView: View;
  setView: (view: View) => void;
  businessName: string;
  setBusinessName: (name: string) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ currentView, setView, businessName, setBusinessName }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isInstalled, setIsInstalled] = useState(false);

  useEffect(() => {
    // Vérifier si on est déjà dans l'application installée (mode standalone)
    if (window.matchMedia('(display-mode: standalone)').matches) {
      setIsInstalled(true);
    }

    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      setDeferredPrompt(e);
    });

    window.addEventListener('appinstalled', () => {
      setDeferredPrompt(null);
      setIsInstalled(true);
      alert("✅ FÉLICITATIONS ! Le logiciel est maintenant installé sur votre PC.\n\nRegardez sur votre BUREAU (écran d'accueil), vous verrez l'icône ComptaSimple.\n\nVous pouvez maintenant fermer votre navigateur internet et utiliser uniquement l'icône du bureau.");
    });
  }, []);

  const handleInstallClick = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') setDeferredPrompt(null);
    } else if (isInstalled) {
      alert("Le logiciel est déjà installé sur votre ordinateur ! Cherchez l'icône sur votre Bureau.");
    } else {
      alert("Pour installer : Cliquez sur la petite flèche 'Installer' qui se trouve tout en haut à droite de votre barre d'adresse (près de l'étoile des favoris).");
    }
  };

  const menuItems = [
    { id: 'dashboard', label: 'Tableau de Bord', icon: '📊' },
    { id: 'journal', label: 'Journal Complet', icon: '📖' },
    { id: 'invoices', label: 'Mes Factures', icon: '📄' },
    { id: 'expenses', label: 'Mes Dépenses', icon: '💸' },
    { id: 'amortization', label: 'Véhicules & Équipement', icon: '🚜' },
    { id: 'reports', label: 'Rapports Impôts', icon: '📈' },
    { id: 'settings', label: 'Options & PC', icon: '⚙️' },
  ];

  return (
    <div className="w-64 bg-slate-900 text-white flex flex-col hidden md:flex min-h-screen sticky top-0 border-r border-slate-800">
      <div className="p-6 border-b border-slate-800 bg-slate-950/50">
        {isEditing ? (
          <div className="space-y-2">
            <input
              autoFocus
              className="bg-slate-800 text-white text-sm w-full p-2 rounded border border-indigo-500 outline-none"
              value={businessName}
              onChange={(e) => setBusinessName(e.target.value)}
              onBlur={() => setIsEditing(false)}
              onKeyDown={(e) => e.key === 'Enter' && setIsEditing(false)}
            />
          </div>
        ) : (
          <div className="group cursor-pointer" onClick={() => setIsEditing(true)}>
            <h1 className="text-xl font-black tracking-tighter truncate">{businessName}</h1>
            <p className="text-indigo-400 text-[10px] mt-1 uppercase font-black tracking-widest flex items-center gap-1">
              LOGICIEL ACTIF <span className="opacity-50">✏️</span>
            </p>
          </div>
        )}
      </div>

      <nav className="flex-1 mt-6 px-4 space-y-1">
        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setView(item.id as View)}
            className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-all duration-200 ${
              currentView === item.id 
                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-900/20' 
                : 'text-slate-400 hover:bg-slate-800 hover:text-white'
            }`}
          >
            <span className="text-xl">{item.icon}</span>
            <span className="font-bold text-sm">{item.label}</span>
          </button>
        ))}
      </nav>

      <div className="p-4 mt-auto border-t border-slate-800 bg-slate-900/50">
        {!isInstalled ? (
          <button 
            onClick={handleInstallClick}
            className="w-full bg-emerald-600 hover:bg-emerald-500 text-white p-5 rounded-2xl flex flex-col items-center justify-center gap-1 transition-all active:scale-95 shadow-xl animate-bounce"
          >
            <span className="text-3xl">📥</span>
            <span className="font-black text-sm uppercase tracking-tighter">Télécharger & Démarrer</span>
            <span className="text-[10px] font-bold uppercase opacity-80">Installer sur le Bureau</span>
          </button>
        ) : (
          <div className="bg-slate-800/50 p-4 rounded-2xl text-center border border-slate-700">
            <span className="text-emerald-400 text-xl block mb-1">✅</span>
            <span className="text-[10px] font-black uppercase text-slate-400 tracking-widest">Logiciel Installé sur PC</span>
          </div>
        )}
        <div className="mt-4 text-center">
          <p className="text-[9px] text-slate-500 font-bold uppercase tracking-[0.2em]">Version Professionnelle 3.1</p>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
