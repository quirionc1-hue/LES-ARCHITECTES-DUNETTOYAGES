
import React, { useRef } from 'react';
import { Invoice, Expense, Asset } from '../types';

interface SettingsViewProps {
  businessName: string;
  setBusinessName: (name: string) => void;
  data: {
    businessName: string;
    invoices: Invoice[];
    expenses: Expense[];
    assets: Asset[];
  };
  onImport: (data: any) => void;
  onInstall: () => void;
  canInstall: boolean;
}

const SettingsView: React.FC<SettingsViewProps> = ({ businessName, setBusinessName, data, onImport, onInstall, canInstall }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const exportToJson = () => {
    const date = new Date().toLocaleDateString('fr-CA').replace(/\//g, '-');
    // Changement du nom pour être ultra-clair
    const fileName = `OUVRIR_DANS_COMPTASIMPLE_${businessName.replace(/\s+/g, '_')}_${date}.json`;
    const jsonStr = JSON.stringify(data, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    alert("✅ SAUVEGARDE RÉUSSIE !\n\nLe fichier est dans votre dossier 'Téléchargements'.\n\nRangez-le précieusement dans votre dossier 'COMPTABILITÉ'.");
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const importedData = JSON.parse(event.target?.result as string);
        onImport(importedData);
      } catch (err) {
        alert("⚠️ ERREUR : Ce fichier ne peut pas être ouvert.\n\nAssurez-vous de choisir un fichier que vous avez déjà téléchargé avec ce logiciel.");
      }
    };
    reader.readAsText(file);
  };

  const downloadCSV = (name: string, headers: string[], rows: string[][]) => {
    const date = new Date().toLocaleDateString('fr-CA').replace(/\//g, '-');
    const csvContent = [
      headers.join(','),
      ...rows.map(r => r.join(','))
    ].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `${name}_${date}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-8 max-w-4xl mx-auto pb-20">
      <header className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100 flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-black text-slate-900 uppercase tracking-tighter">Votre Logiciel PC</h2>
          <p className="text-slate-500 font-medium">Gérez votre installation et vos fichiers de données.</p>
        </div>
        <div className="bg-indigo-50 px-4 py-2 rounded-xl border border-indigo-100 font-black text-indigo-600 text-xs">
          MODE SÉCURISÉ
        </div>
      </header>

      {/* ZONE D'ACTION PRINCIPALE */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* BOUTON SAUVEGARDE */}
        <section className="bg-white p-8 rounded-[2rem] shadow-xl border-t-8 border-indigo-600 space-y-6 flex flex-col">
          <div className="flex items-center gap-3">
            <span className="text-3xl">💾</span>
            <h3 className="text-xl font-black text-slate-800 uppercase">Enregistrer mon travail</h3>
          </div>
          <p className="text-sm text-slate-500 flex-1">
            Cliquez ici pour créer un fichier de secours. Si vous perdez votre ordinateur, ce fichier vous permettra de retrouver toute votre comptabilité.
          </p>
          <button 
            onClick={exportToJson}
            className="w-full bg-indigo-600 text-white py-6 rounded-2xl font-black uppercase tracking-widest hover:bg-indigo-700 transition-all shadow-lg text-lg"
          >
            CRÉER UNE SAUVEGARDE
          </button>
        </section>

        {/* BOUTON CHARGER */}
        <section className="bg-white p-8 rounded-[2rem] shadow-xl border-t-8 border-slate-200 space-y-6 flex flex-col">
          <div className="flex items-center gap-3">
            <span className="text-3xl">📂</span>
            <h3 className="text-xl font-black text-slate-800 uppercase">Ouvrir mes comptes</h3>
          </div>
          <p className="text-sm text-slate-500 flex-1">
            Utilisez ce bouton pour charger un fichier que vous avez enregistré précédemment. Cela remplacera les données actuelles.
          </p>
          <button 
            onClick={() => fileInputRef.current?.click()}
            className="w-full bg-slate-100 text-slate-700 py-6 rounded-2xl font-black uppercase tracking-widest hover:bg-slate-200 transition-all border-2 border-slate-200 text-lg"
          >
            CHOISIR UN FICHIER
          </button>
          <input 
            type="file" 
            ref={fileInputRef} 
            className="hidden" 
            accept=".json" 
            onChange={handleFileUpload}
          />
        </section>
      </div>

      {/* AIDE VISUELLE */}
      <div className="bg-emerald-900 text-white p-10 rounded-[2.5rem] shadow-2xl relative overflow-hidden">
        <div className="relative z-10">
          <h3 className="text-2xl font-black uppercase tracking-widest mb-6">Comment démarrer le logiciel ?</h3>
          <div className="space-y-6">
            <div className="flex gap-4">
              <span className="bg-white text-emerald-900 w-8 h-8 rounded-full flex items-center justify-center font-black flex-shrink-0">1</span>
              <p className="font-bold">Installez-le avec le gros bouton vert à gauche (📥 Télécharger & Démarrer).</p>
            </div>
            <div className="flex gap-4">
              <span className="bg-white text-emerald-900 w-8 h-8 rounded-full flex items-center justify-center font-black flex-shrink-0">2</span>
              <p className="font-bold">Une fois installé, allez sur votre Bureau Windows. Cherchez l'icône <span className="underline">ComptaSimple</span>.</p>
            </div>
            <div className="flex gap-4">
              <span className="bg-white text-emerald-900 w-8 h-8 rounded-full flex items-center justify-center font-black flex-shrink-0">3</span>
              <p className="font-bold">Double-cliquez sur l'icône : Le programme s'ouvre tout seul dans sa propre fenêtre, comme un vrai logiciel professionnel !</p>
            </div>
          </div>
        </div>
        <div className="absolute -right-20 -bottom-20 text-[15rem] opacity-10">💻</div>
      </div>

      {/* EXCEL */}
      <section className="bg-white p-8 rounded-3xl shadow-sm border-2 border-slate-50">
        <h3 className="text-sm font-black text-slate-400 uppercase tracking-widest mb-4">Exportation pour Tableur</h3>
        <div className="flex flex-col md:flex-row gap-4">
          <button 
            onClick={() => downloadCSV('VENTES', ['Date', 'Client', 'Total TTC'], data.invoices.map(i => [i.date, i.clientName, i.totalTTC.toFixed(2)]))}
            className="flex-1 border-2 border-emerald-500 text-emerald-700 py-3 rounded-xl font-bold hover:bg-emerald-50 transition-all"
          >
            Liste des Ventes (Excel)
          </button>
          <button 
            onClick={() => downloadCSV('DEPENSES', ['Date', 'Raison', 'Total TTC'], data.expenses.map(e => [e.date, e.description, e.totalTTC.toFixed(2)]))}
            className="flex-1 border-2 border-emerald-500 text-emerald-700 py-3 rounded-xl font-bold hover:bg-emerald-50 transition-all"
          >
            Liste des Dépenses (Excel)
          </button>
        </div>
      </section>
    </div>
  );
};

export default SettingsView;
