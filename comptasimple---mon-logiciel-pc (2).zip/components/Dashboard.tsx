
import React, { useState, useEffect } from 'react';
import { Invoice, Expense, QuarterlySummary, ExpenseCategory } from '../types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { analyzeFinances } from '../services/geminiService';

interface DashboardProps {
  invoices: Invoice[];
  expenses: Expense[];
}

const Dashboard: React.FC<DashboardProps> = ({ invoices, expenses }) => {
  const [analysis, setAnalysis] = useState<string>('Chargement de l\'analyse intelligente...');
  
  const currentMonth = new Date().getMonth();
  const currentQuarter = Math.floor(currentMonth / 3) + 1;
  const currentYear = new Date().getFullYear();

  const calculateSummary = (q: number, y: number): QuarterlySummary => {
    const qInvoices = invoices.filter(inv => {
      const d = new Date(inv.date);
      return Math.floor(d.getMonth() / 3) + 1 === q && d.getFullYear() === y;
    });

    const qExpenses = expenses.filter(exp => {
      const d = new Date(exp.date);
      return Math.floor(d.getMonth() / 3) + 1 === q && d.getFullYear() === y;
    });

    const revenueHT = qInvoices.reduce((acc, curr) => acc + curr.totalHT, 0);
    const tpsCollected = qInvoices.reduce((acc, curr) => acc + curr.totalTPS, 0);
    const tvqCollected = qInvoices.reduce((acc, curr) => acc + curr.totalTVQ, 0);
    
    const expensesHT = qExpenses.reduce((acc, curr) => acc + curr.amountHT, 0);
    const tpsPaid = qExpenses.reduce((acc, curr) => acc + curr.tpsAmount, 0);
    const tvqPaid = qExpenses.reduce((acc, curr) => acc + curr.tvqAmount, 0);

    const expensesByCategory = qExpenses.reduce((acc, curr) => {
      acc[curr.category] = (acc[curr.category] || 0) + curr.amountHT;
      return acc;
    }, {} as Record<ExpenseCategory, number>);

    return {
      quarter: q,
      year: y,
      revenueHT,
      tpsCollected,
      tvqCollected,
      expensesHT,
      tpsPaid,
      tvqPaid,
      netIncome: revenueHT - expensesHT,
      expensesByCategory: {
        [ExpenseCategory.OFFICE]: expensesByCategory[ExpenseCategory.OFFICE] || 0,
        [ExpenseCategory.SUPPLIES]: expensesByCategory[ExpenseCategory.SUPPLIES] || 0,
        [ExpenseCategory.SUPPLIES_NO_TAX]: expensesByCategory[ExpenseCategory.SUPPLIES_NO_TAX] || 0,
        [ExpenseCategory.AUTOMOBILE]: expensesByCategory[ExpenseCategory.AUTOMOBILE] || 0,
        [ExpenseCategory.OTHER]: expensesByCategory[ExpenseCategory.OTHER] || 0,
      }
    };
  };

  const summary = calculateSummary(currentQuarter, currentYear);

  useEffect(() => {
    const fetchAnalysis = async () => {
      const result = await analyzeFinances(invoices, expenses, summary);
      setAnalysis(result || "Aucune analyse disponible.");
    };
    fetchAnalysis();
  }, [invoices, expenses, currentQuarter]);

  const chartData = [
    { name: 'Revenu HT', value: summary.revenueHT, color: '#4F46E5' },
    { name: 'Dépenses HT', value: summary.expensesHT, color: '#EF4444' },
    { name: 'Bénéfice Net', value: summary.netIncome, color: '#F59E0B' },
  ];

  const netTPS = summary.tpsCollected - summary.tpsPaid;
  const netTVQ = summary.tvqCollected - summary.tvqPaid;

  return (
    <div className="space-y-6">
      <header className="flex flex-col md:flex-row justify-between items-start md:items-center">
        <div>
          <h2 className="text-3xl font-extrabold text-gray-900">Tableau de Bord Québec</h2>
          <p className="text-gray-500">Aperçu du Trimestre Q{currentQuarter} {currentYear}</p>
        </div>
        <div className="mt-2 md:mt-0 bg-white px-4 py-2 rounded-lg border shadow-sm flex items-center space-x-2">
          <span className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></span>
          <span className="text-sm font-bold text-gray-700">Calcul en temps réel (CAD)</span>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="Ventes (HT)" value={summary.revenueHT} unit="$" color="indigo" />
        <StatCard title="Dépenses (HT)" value={summary.expensesHT} unit="$" color="red" />
        <StatCard title="TPS à remettre" value={netTPS} unit="$" color="emerald" />
        <StatCard title="TVQ à remettre" value={netTVQ} unit="$" color="amber" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white p-6 rounded-xl shadow-sm border">
          <h3 className="text-lg font-bold mb-6">Volume d'Affaire HT vs Bénéfice</h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip formatter={(value) => `${value} $`} />
                <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                  {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-blue-50 p-6 rounded-xl shadow-sm border border-blue-100 flex flex-col">
          <div className="flex items-center space-x-2 mb-4">
            <span className="text-xl">🍁</span>
            <h3 className="text-lg font-bold text-blue-900">Conseiller IA Québec</h3>
          </div>
          <div className="flex-1 text-blue-800 text-sm italic leading-relaxed whitespace-pre-line">
            "{analysis}"
          </div>
          <div className="mt-4 pt-4 border-t border-blue-200 text-xs text-blue-500 font-medium">
            Propulsé par Gemini AI
          </div>
        </div>
      </div>
      
      <div className="bg-white p-6 rounded-xl shadow-sm border">
        <h3 className="text-lg font-bold mb-4">Détails des Taxes pour Remise</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-gray-50 p-4 rounded-lg space-y-2 border border-gray-100">
            <div className="flex justify-between items-center text-sm">
              <span className="text-gray-600 font-medium">TPS Collectée (Ventes)</span>
              <span className="font-bold text-green-600">+{summary.tpsCollected.toFixed(2)} $</span>
            </div>
            <div className="flex justify-between items-center text-sm">
              <span className="text-gray-600 font-medium">TPS Payée (ITC)</span>
              <span className="font-bold text-red-600">-{summary.tpsPaid.toFixed(2)} $</span>
            </div>
            <div className="pt-2 border-t flex justify-between items-center">
              <span className="font-bold">Net TPS</span>
              <span className="text-xl font-black">{netTPS.toFixed(2)} $</span>
            </div>
          </div>

          <div className="bg-gray-50 p-4 rounded-lg space-y-2 border border-gray-100">
            <div className="flex justify-between items-center text-sm">
              <span className="text-gray-600 font-medium">TVQ Collectée (Ventes)</span>
              <span className="font-bold text-green-600">+{summary.tvqCollected.toFixed(2)} $</span>
            </div>
            <div className="flex justify-between items-center text-sm">
              <span className="text-gray-600 font-medium">TVQ Payée (ITR)</span>
              <span className="font-bold text-red-600">-{summary.tvqPaid.toFixed(2)} $</span>
            </div>
            <div className="pt-2 border-t flex justify-between items-center">
              <span className="font-bold">Net TVQ</span>
              <span className="text-xl font-black">{netTVQ.toFixed(2)} $</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const StatCard: React.FC<{ title: string; value: number; unit: string; color: string }> = ({ title, value, unit, color }) => {
  const colorClasses: Record<string, string> = {
    indigo: 'border-indigo-200 bg-indigo-50 text-indigo-600',
    red: 'border-red-200 bg-red-50 text-red-600',
    emerald: 'border-emerald-200 bg-emerald-50 text-emerald-600',
    amber: 'border-amber-200 bg-amber-50 text-amber-600',
  };

  return (
    <div className={`p-6 rounded-xl border shadow-sm ${colorClasses[color] || 'bg-white'}`}>
      <h4 className="text-sm font-medium opacity-80 uppercase tracking-wider">{title}</h4>
      <p className="text-2xl font-black mt-2">
        {value.toLocaleString('fr-CA', { minimumFractionDigits: 2 })} {unit}
      </p>
    </div>
  );
};

export default Dashboard;
