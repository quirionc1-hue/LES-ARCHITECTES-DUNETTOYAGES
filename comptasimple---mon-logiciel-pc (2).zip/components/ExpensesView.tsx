
import React, { useState, useMemo } from 'react';
import { Expense, ExpenseCategory } from '../types';

interface ExpensesViewProps {
  expenses: Expense[];
  onAdd: (expense: Expense) => void;
  onDelete: (id: string) => void;
}

const ExpensesView: React.FC<ExpensesViewProps> = ({ expenses, onAdd, onDelete }) => {
  const [showForm, setShowForm] = useState(false);
  const [description, setDescription] = useState('');
  const [amountHT, setAmountHT] = useState(0);
  const [tpsAmount, setTpsAmount] = useState(0);
  const [tvqAmount, setTvqAmount] = useState(0);
  const [category, setCategory] = useState<ExpenseCategory>(ExpenseCategory.OFFICE);
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [isNoTax, setIsNoTax] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const finalTps = isNoTax ? 0 : tpsAmount;
    const finalTvq = isNoTax ? 0 : tvqAmount;
    
    const newExpense: Expense = {
      id: crypto.randomUUID(),
      date,
      description,
      amountHT,
      tpsAmount: finalTps,
      tvqAmount: finalTvq,
      totalTTC: amountHT + finalTps + finalTvq,
      category: isNoTax && category !== ExpenseCategory.SUPPLIES_NO_TAX ? ExpenseCategory.SUPPLIES_NO_TAX : category
    };
    onAdd(newExpense);
    setDescription('');
    setAmountHT(0);
    setTpsAmount(0);
    setTvqAmount(0);
    setIsNoTax(false);
    setShowForm(false);
  };

  const noTaxExpenses = useMemo(() => 
    expenses.filter(e => e.category === ExpenseCategory.SUPPLIES_NO_TAX || (e.tpsAmount === 0 && e.tvqAmount === 0)),
    [expenses]
  );

  const totalNoTax = noTaxExpenses.reduce((acc, curr) => acc + curr.amountHT, 0);

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Registre des Dépenses</h2>
          <p className="text-sm text-gray-500">Capture des ITCs (TPS) et ITRs (TVQ) payés</p>
        </div>
        <div className="flex gap-2 w-full md:w-auto">
          <button
            onClick={() => { setShowForm(!showForm); setIsNoTax(true); setCategory(ExpenseCategory.SUPPLIES_NO_TAX); }}
            className="flex-1 md:flex-none bg-emerald-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-emerald-700 transition-colors shadow-lg text-sm"
          >
            + Fourniture Sans Taxe
          </button>
          <button
            onClick={() => { setShowForm(!showForm); setIsNoTax(false); }}
            className="flex-1 md:flex-none bg-red-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-red-700 transition-colors shadow-lg text-sm"
          >
            {showForm ? 'Annuler' : '+ Dépense Standard'}
          </button>
        </div>
      </div>

      {/* Section Spécifique Fournitures Sans Taxe Summary */}
      <div className="bg-emerald-50 border border-emerald-100 rounded-xl p-4 flex justify-between items-center shadow-sm">
        <div className="flex items-center gap-3">
          <span className="text-2xl">📦</span>
          <div>
            <h3 className="text-emerald-900 font-bold text-sm uppercase tracking-wider">Fournitures Sans Taxe</h3>
            <p className="text-xs text-emerald-600">Achats exonérés ou détaxés</p>
          </div>
        </div>
        <div className="text-right">
          <p className="text-2xl font-black text-emerald-700">{totalNoTax.toFixed(2)} $</p>
          <p className="text-[10px] font-bold text-emerald-500 uppercase">Total Cumulé</p>
        </div>
      </div>

      {showForm && (
        <form onSubmit={handleSubmit} className={`bg-white p-6 rounded-xl shadow-md border ${isNoTax ? 'border-emerald-200' : 'border-red-100'} space-y-4 transition-all animate-in fade-in slide-in-from-top-4 duration-300`}>
          <div className="flex items-center gap-2 mb-2">
            <input 
              type="checkbox" 
              id="noTaxToggle" 
              checked={isNoTax} 
              onChange={(e) => {
                setIsNoTax(e.target.checked);
                if(e.target.checked) setCategory(ExpenseCategory.SUPPLIES_NO_TAX);
              }}
              className="w-4 h-4 text-emerald-600 rounded focus:ring-emerald-500"
            />
            <label htmlFor="noTaxToggle" className="text-sm font-bold text-gray-700 cursor-pointer">
              Cette dépense est sans taxes (Exonérée / Détaxée)
            </label>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="md:col-span-2 lg:col-span-1">
              <label className="block text-sm font-medium text-gray-700">Fournisseur / Raison</label>
              <input
                type="text"
                required
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm p-2 border focus:ring-2 focus:ring-indigo-500"
                placeholder="Ex: Bureau en Gros / Tim Hortons"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">Catégorie</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as ExpenseCategory)}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm p-2 border focus:ring-2 focus:ring-indigo-500"
              >
                {Object.values(ExpenseCategory).map(cat => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">Date d'achat</label>
              <input
                type="date"
                required
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm p-2 border focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">Montant HT ($)</label>
              <input
                type="number"
                step="0.01"
                required
                value={amountHT}
                onChange={(e) => setAmountHT(Number(e.target.value))}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm p-2 border focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            {!isNoTax && (
              <>
                <div>
                  <label className="block text-sm font-medium text-gray-700">TPS Payée ($)</label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    value={tpsAmount}
                    onChange={(e) => setTpsAmount(Number(e.target.value))}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm p-2 border focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">TVQ Payée ($)</label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    value={tvqAmount}
                    onChange={(e) => setTvqAmount(Number(e.target.value))}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm p-2 border focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
              </>
            )}
          </div>
          
          <div className={`pt-4 flex justify-between items-center ${isNoTax ? 'bg-emerald-50' : 'bg-gray-50'} p-4 rounded-lg border border-dashed`}>
            <div className="text-gray-600 font-medium">
              Total TTC : <span className={`text-xl font-bold ${isNoTax ? 'text-emerald-700' : 'text-gray-900'}`}>
                {(amountHT + (isNoTax ? 0 : (tpsAmount + tvqAmount))).toFixed(2)} $
              </span>
            </div>
            <button type="submit" className={`${isNoTax ? 'bg-emerald-600 hover:bg-emerald-700' : 'bg-red-600 hover:bg-red-700'} text-white px-8 py-2 rounded-xl font-bold shadow-md transition-colors`}>
              Enregistrer
            </button>
          </div>
        </form>
      )}

      <div className="bg-white rounded-xl shadow-sm border overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-bold text-gray-400 uppercase">Date</th>
              <th className="px-6 py-3 text-left text-xs font-bold text-gray-400 uppercase">Description</th>
              <th className="px-6 py-3 text-left text-xs font-bold text-gray-400 uppercase">Catégorie</th>
              <th className="px-6 py-3 text-right text-xs font-bold text-gray-400 uppercase">HT</th>
              <th className="px-6 py-3 text-right text-xs font-bold text-gray-400 uppercase">TPS</th>
              <th className="px-6 py-3 text-right text-xs font-bold text-gray-400 uppercase">TVQ</th>
              <th className="px-6 py-3 text-right text-xs font-bold text-gray-400 uppercase">Total TTC</th>
              <th className="px-6 py-3 text-center text-xs font-bold text-gray-400 uppercase">Action</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {expenses.length === 0 && (
              <tr>
                <td colSpan={8} className="px-6 py-10 text-center text-gray-400 italic">Aucune dépense enregistrée.</td>
              </tr>
            )}
            {expenses.map((exp) => (
              <tr key={exp.id} className={`hover:bg-gray-50 transition-colors ${exp.category === ExpenseCategory.SUPPLIES_NO_TAX ? 'bg-emerald-50/20' : ''}`}>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{new Date(exp.date).toLocaleDateString('fr-CA')}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-bold text-gray-900">{exp.description}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm">
                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                    exp.category === ExpenseCategory.AUTOMOBILE ? 'bg-blue-100 text-blue-700' :
                    exp.category === ExpenseCategory.OFFICE ? 'bg-purple-100 text-purple-700' :
                    exp.category === ExpenseCategory.SUPPLIES ? 'bg-orange-100 text-orange-700' :
                    exp.category === ExpenseCategory.SUPPLIES_NO_TAX ? 'bg-emerald-100 text-emerald-700' :
                    'bg-gray-100 text-gray-700'
                  }`}>
                    {exp.category}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-right font-medium text-gray-900">{exp.amountHT.toFixed(2)} $</td>
                <td className={`px-6 py-4 whitespace-nowrap text-sm text-right ${exp.tpsAmount === 0 ? 'text-gray-300 italic' : 'text-red-400'}`}>
                  {exp.tpsAmount === 0 ? 'Exonéré' : `${exp.tpsAmount.toFixed(2)} $`}
                </td>
                <td className={`px-6 py-4 whitespace-nowrap text-sm text-right ${exp.tvqAmount === 0 ? 'text-gray-300 italic' : 'text-red-500'}`}>
                  {exp.tvqAmount === 0 ? 'Exonéré' : `${exp.tvqAmount.toFixed(2)} $`}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-right font-black text-red-700">{exp.totalTTC.toFixed(2)} $</td>
                <td className="px-6 py-4 whitespace-nowrap text-center">
                  <button onClick={() => onDelete(exp.id)} className="text-red-400 hover:text-red-600 p-2 rounded hover:bg-red-50">
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default ExpensesView;
