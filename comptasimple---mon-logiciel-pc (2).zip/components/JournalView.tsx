
import React, { useState, useMemo } from 'react';
import { Invoice, Expense } from '../types';

interface JournalViewProps {
  invoices: Invoice[];
  expenses: Expense[];
  onDeleteInvoice: (id: string) => void;
  onDeleteExpense: (id: string) => void;
}

interface UnifiedTransaction {
  id: string;
  date: string;
  type: 'VENTE' | 'DÉPENSE';
  name: string; // Client ou Fournisseur
  description: string;
  amountHT: number;
  tps: number;
  tvq: number;
  totalTTC: number;
  originalType: 'invoice' | 'expense';
}

const JournalView: React.FC<JournalViewProps> = ({ invoices, expenses, onDeleteInvoice, onDeleteExpense }) => {
  const [searchTerm, setSearchTerm] = useState('');

  const allTransactions = useMemo(() => {
    const list: UnifiedTransaction[] = [];

    invoices.forEach(inv => {
      list.push({
        id: inv.id,
        date: inv.date,
        type: 'VENTE',
        name: inv.clientName,
        description: inv.items.map(i => i.description).join(', '),
        amountHT: inv.totalHT,
        tps: inv.totalTPS,
        tvq: inv.totalTVQ,
        totalTTC: inv.totalTTC,
        originalType: 'invoice'
      });
    });

    expenses.forEach(exp => {
      list.push({
        id: exp.id,
        date: exp.date,
        type: 'DÉPENSE',
        name: exp.description, // Souvent le nom du fournisseur
        description: exp.category,
        amountHT: exp.amountHT,
        tps: exp.tpsAmount,
        tvq: exp.tvqAmount,
        totalTTC: exp.totalTTC,
        originalType: 'expense'
      });
    });

    // Trier par date décroissante (plus récent en haut)
    return list.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [invoices, expenses]);

  const filteredTransactions = useMemo(() => {
    if (!searchTerm) return allTransactions;
    const lower = searchTerm.toLowerCase();
    return allTransactions.filter(t => 
      t.name.toLowerCase().includes(lower) || 
      t.description.toLowerCase().includes(lower) ||
      t.date.includes(lower)
    );
  }, [allTransactions, searchTerm]);

  return (
    <div className="space-y-6">
      <header className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h2 className="text-3xl font-black text-slate-900 uppercase tracking-tighter italic">Journal Complet</h2>
            <p className="text-slate-500 font-medium">Voir absolument toutes vos écritures sans filtre.</p>
          </div>
          <div className="relative w-full md:w-96">
            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 text-xl">🔍</span>
            <input 
              type="text" 
              placeholder="Rechercher un client, fournisseur ou date..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-12 pr-4 py-4 bg-slate-100 border-2 border-transparent focus:border-indigo-500 rounded-2xl outline-none font-bold transition-all"
            />
          </div>
        </div>
      </header>

      <div className="bg-white rounded-[2rem] shadow-xl border overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-slate-100">
            <thead className="bg-slate-50">
              <tr className="text-xs font-black text-slate-400 uppercase tracking-[0.2em]">
                <th className="px-8 py-6 text-left">Date</th>
                <th className="px-4 py-6 text-center">Type</th>
                <th className="px-6 py-6 text-left">Client / Raison</th>
                <th className="px-6 py-6 text-left">Description</th>
                <th className="px-4 py-6 text-right">Montant HT</th>
                <th className="px-4 py-6 text-right">Taxes</th>
                <th className="px-8 py-6 text-right">Total TTC</th>
                <th className="px-4 py-6 text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {filteredTransactions.length === 0 && (
                <tr>
                  <td colSpan={8} className="px-8 py-20 text-center">
                    <div className="flex flex-col items-center gap-4">
                      <span className="text-6xl opacity-20">📂</span>
                      <p className="text-slate-400 font-black uppercase tracking-widest text-sm italic">Aucune transaction trouvée</p>
                    </div>
                  </td>
                </tr>
              )}
              {filteredTransactions.map((t) => (
                <tr key={`${t.originalType}-${t.id}`} className="hover:bg-slate-50/50 transition-colors group">
                  <td className="px-8 py-5 whitespace-nowrap text-sm font-bold text-slate-500">
                    {new Date(t.date).toLocaleDateString('fr-CA')}
                  </td>
                  <td className="px-4 py-5 whitespace-nowrap text-center">
                    <span className={`px-3 py-1 rounded-full text-[10px] font-black tracking-widest uppercase ${
                      t.type === 'VENTE' ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700'
                    }`}>
                      {t.type}
                    </span>
                  </td>
                  <td className="px-6 py-5 whitespace-nowrap text-sm font-black text-slate-800">
                    {t.name}
                  </td>
                  <td className="px-6 py-5 text-sm text-slate-500 italic max-w-xs truncate">
                    {t.description}
                  </td>
                  <td className="px-4 py-5 whitespace-nowrap text-right text-sm font-bold text-slate-700">
                    {t.amountHT.toFixed(2)} $
                  </td>
                  <td className="px-4 py-5 whitespace-nowrap text-right text-xs font-medium text-slate-400">
                    +{(t.tps + t.tvq).toFixed(2)} $
                  </td>
                  <td className={`px-8 py-5 whitespace-nowrap text-right text-lg font-black ${
                    t.type === 'VENTE' ? 'text-emerald-600' : 'text-red-600'
                  }`}>
                    {t.totalTTC.toFixed(2)} $
                  </td>
                  <td className="px-4 py-5 whitespace-nowrap text-center">
                    <button 
                      onClick={() => t.originalType === 'invoice' ? onDeleteInvoice(t.id) : onDeleteExpense(t.id)}
                      className="text-slate-300 hover:text-red-500 p-2 transition-colors"
                    >
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="bg-slate-900 text-white p-6 rounded-[2rem] flex flex-col md:flex-row justify-between items-center gap-4">
        <div className="flex gap-8">
          <div>
            <p className="text-slate-400 text-[10px] font-black uppercase tracking-widest mb-1">Nombre d'opérations</p>
            <p className="text-2xl font-black">{filteredTransactions.length}</p>
          </div>
          <div>
            <p className="text-slate-400 text-[10px] font-black uppercase tracking-widest mb-1">Volume d'affaires HT</p>
            <p className="text-2xl font-black text-emerald-400">{filteredTransactions.filter(t => t.type === 'VENTE').reduce((acc, curr) => acc + curr.amountHT, 0).toFixed(2)} $</p>
          </div>
        </div>
        <p className="text-slate-500 text-[10px] font-bold uppercase italic tracking-widest text-center md:text-right">
          Données brutes sans arrondis ni filtres trimestriels.
        </p>
      </div>
    </div>
  );
};

export default JournalView;
