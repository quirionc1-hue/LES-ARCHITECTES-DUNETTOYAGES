
import React, { useState } from 'react';
import { Asset, AssetType } from '../types';

interface AmortizationViewProps {
  assets: Asset[];
  onSave: (assets: Asset[]) => void;
}

const AmortizationView: React.FC<AmortizationViewProps> = ({ assets, onSave }) => {
  const [showForm, setShowForm] = useState(false);
  const [name, setName] = useState('');
  const [type, setType] = useState<AssetType>(AssetType.AUTO);
  const [cost, setCost] = useState(0);
  const [openingUCC, setOpeningUCC] = useState(0); // Montant de l'an passé (FNACC)

  const handleAddAsset = (e: React.FormEvent) => {
    e.preventDefault();
    let rate = 0.20;
    if (type === AssetType.AUTO) rate = 0.30;
    if (type === AssetType.COMPUTER) rate = 0.55;

    const newAsset: Asset = {
      id: crypto.randomUUID(),
      name,
      type,
      purchaseDate: new Date().toISOString().split('T')[0],
      cost,
      openingUCC,
      additions: 0,
      disposals: 0,
      ccaRate: rate
    };
    onSave([...assets, newAsset]);
    setName('');
    setCost(0);
    setOpeningUCC(0);
    setShowForm(false);
  };

  const deleteAsset = (id: string) => {
    onSave(assets.filter(a => a.id !== id));
  };

  const calculateCCA = (asset: Asset) => {
    // Règle de la demi-année pour les nouvelles acquisitions (simplifiée)
    // DPA = (Ouverture + 50% des additions nettes) * Taux
    const netAddition = asset.additions - asset.disposals;
    const baseForCCA = asset.openingUCC + (netAddition > 0 ? netAddition * 0.5 : netAddition);
    const ccaAmount = baseForCCA * asset.ccaRate;
    const closingUCC = asset.openingUCC + netAddition - ccaAmount;
    
    return { ccaAmount, closingUCC };
  };

  return (
    <div className="space-y-8">
      <header className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-black text-slate-900 uppercase tracking-tighter">Amortissement (DPA)</h2>
          <p className="text-slate-500">Déduction pour amortissement selon les catégories de l'ARC et Revenu Québec</p>
        </div>
        <button
          onClick={() => setShowForm(!showForm)}
          className="bg-indigo-600 text-white px-6 py-2 rounded-xl font-bold shadow-lg hover:bg-indigo-700 transition-all"
        >
          {showForm ? 'Annuler' : '+ Nouvel Actif / Solde Ouverture'}
        </button>
      </header>

      {showForm && (
        <form onSubmit={handleAddAsset} className="bg-white p-8 rounded-3xl shadow-xl border-2 border-indigo-50 space-y-6">
          <h3 className="text-xl font-bold text-indigo-900 border-b pb-2 italic">Détails de l'Actif</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="col-span-1 lg:col-span-2">
              <label className="block text-xs font-black text-slate-400 uppercase mb-1">Nom de l'Actif (ex: Ford F-150)</label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full p-3 border-2 border-slate-100 rounded-xl focus:border-indigo-500 outline-none transition-all"
                placeholder="Désignation de l'équipement ou véhicule"
              />
            </div>
            <div>
              <label className="block text-xs font-black text-slate-400 uppercase mb-1">Catégorie Fiscale</label>
              <select
                value={type}
                onChange={(e) => setType(e.target.value as AssetType)}
                className="w-full p-3 border-2 border-slate-100 rounded-xl focus:border-indigo-500 outline-none transition-all"
              >
                {Object.values(AssetType).map(t => (
                  <option key={t} value={t}>{t}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-black text-slate-400 uppercase mb-1">Coût d'Achat Initial ($)</label>
              <input
                type="number"
                required
                value={cost}
                onChange={(e) => setCost(Number(e.target.value))}
                className="w-full p-3 border-2 border-slate-100 rounded-xl focus:border-indigo-500 outline-none transition-all"
              />
            </div>
          </div>

          <div className="bg-amber-50 p-6 rounded-2xl border-2 border-amber-100 flex items-center justify-between">
            <div className="max-w-md">
              <h4 className="font-bold text-amber-900">Montant de l'an passé (Solde Ouverture)</h4>
              <p className="text-xs text-amber-700 italic">Saisissez ici la FNACC (UCC) à la fin de l'exercice précédent pour cet actif.</p>
            </div>
            <div className="w-48">
              <input
                type="number"
                value={openingUCC}
                onChange={(e) => setOpeningUCC(Number(e.target.value))}
                className="w-full p-4 border-2 border-amber-200 rounded-xl bg-white font-black text-xl text-amber-900 shadow-inner"
              />
            </div>
          </div>

          <div className="flex justify-end">
            <button type="submit" className="bg-indigo-900 text-white px-10 py-3 rounded-2xl font-black uppercase tracking-widest shadow-xl hover:bg-black transition-all">
              Ajouter au Tableau
            </button>
          </div>
        </form>
      )}

      {/* Tableaux par catégorie */}
      <div className="space-y-12">
        {[AssetType.AUTO, AssetType.EQUIPMENT, AssetType.COMPUTER].map(catType => {
          const catAssets = assets.filter(a => a.type === catType);
          if (catAssets.length === 0) return null;

          return (
            <div key={catType} className="bg-white rounded-3xl shadow-sm border overflow-hidden">
              <div className="bg-slate-900 p-4 px-8 text-white flex justify-between items-center">
                <h3 className="font-black uppercase tracking-widest text-sm">{catType}</h3>
                <span className="text-[10px] opacity-50 font-bold">CALCUL DPA AUTO-APPLIQUÉ</span>
              </div>
              <table className="w-full text-left">
                <thead className="bg-slate-50 border-b">
                  <tr className="text-[10px] font-black text-slate-400 uppercase tracking-wider">
                    <th className="px-8 py-4">Désignation</th>
                    <th className="px-4 py-4 text-right">Solde Ouverture (FNACC)</th>
                    <th className="px-4 py-4 text-right">Taux</th>
                    <th className="px-4 py-4 text-right">DPA de l'Année</th>
                    <th className="px-4 py-4 text-right">Solde Fermeture</th>
                    <th className="px-8 py-4 text-center">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {catAssets.map(asset => {
                    const { ccaAmount, closingUCC } = calculateCCA(asset);
                    return (
                      <tr key={asset.id} className="hover:bg-slate-50 transition-colors">
                        <td className="px-8 py-4">
                          <p className="font-bold text-slate-900">{asset.name}</p>
                          <p className="text-[10px] text-slate-400">Coût Initial: {asset.cost.toFixed(2)} $</p>
                        </td>
                        <td className="px-4 py-4 text-right font-medium text-slate-600">
                          {asset.openingUCC.toLocaleString('fr-CA', { minimumFractionDigits: 2 })} $
                        </td>
                        <td className="px-4 py-4 text-right text-slate-400 font-bold italic">
                          {(asset.ccaRate * 100).toFixed(0)} %
                        </td>
                        <td className="px-4 py-4 text-right text-indigo-600 font-black">
                          {ccaAmount.toLocaleString('fr-CA', { minimumFractionDigits: 2 })} $
                        </td>
                        <td className="px-4 py-4 text-right bg-slate-50 font-black text-slate-900">
                          {closingUCC.toLocaleString('fr-CA', { minimumFractionDigits: 2 })} $
                        </td>
                        <td className="px-8 py-4 text-center">
                          <button 
                            onClick={() => deleteAsset(asset.id)}
                            className="text-red-300 hover:text-red-600 transition-colors p-2"
                            title="Supprimer cet actif"
                          >
                            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          );
        })}

        {assets.length === 0 && (
          <div className="bg-white border-2 border-dashed border-slate-200 rounded-3xl p-20 text-center space-y-4">
            <span className="text-6xl grayscale opacity-20">🚜</span>
            <p className="text-slate-400 font-bold uppercase tracking-widest text-sm italic">Aucun actif amortissable enregistré</p>
            <p className="text-xs text-slate-300">Ajoutez vos véhicules ou équipements pour calculer votre déduction fiscale (DPA).</p>
          </div>
        )}
      </div>

      <div className="bg-indigo-50 rounded-2xl p-6 border border-indigo-100 flex gap-4 items-start">
         <span className="text-2xl mt-1">💡</span>
         <div>
           <h4 className="font-bold text-indigo-900 uppercase text-xs tracking-widest mb-1">Notes Fiscales Québec</h4>
           <ul className="text-xs text-indigo-800 space-y-1 list-disc pl-4 opacity-80">
             <li>La DPA (Déduction pour Amortissement) réduit votre revenu imposable.</li>
             <li>La règle de la demi-année s'applique aux acquisitions nettes durant l'exercice.</li>
             <li>La catégorie 10.1 s'applique aux voitures de tourisme dépassant 30 000$ (limitation de coût capital).</li>
           </ul>
         </div>
      </div>
    </div>
  );
};

export default AmortizationView;
