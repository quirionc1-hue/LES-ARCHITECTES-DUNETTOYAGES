
import React, { useMemo } from 'react';
import { Invoice, Expense, QuarterlySummary, ExpenseCategory } from '../types';

interface ReportsViewProps {
  invoices: Invoice[];
  expenses: Expense[];
}

const ReportsView: React.FC<ReportsViewProps> = ({ invoices, expenses }) => {
  const currentYear = new Date().getFullYear();

  const quarters = useMemo(() => {
    return [1, 2, 3, 4].map(q => {
      const qInvoices = invoices.filter(inv => {
        const d = new Date(inv.date);
        return Math.floor(d.getMonth() / 3) + 1 === q && d.getFullYear() === currentYear;
      });

      const qExpenses = expenses.filter(exp => {
        const d = new Date(exp.date);
        return Math.floor(d.getMonth() / 3) + 1 === q && d.getFullYear() === currentYear;
      });

      const revHT = qInvoices.reduce((a, c) => a + c.totalHT, 0);
      const tpsColl = qInvoices.reduce((a, c) => a + c.totalTPS, 0);
      const tvqColl = qInvoices.reduce((a, c) => a + c.totalTVQ, 0);
      
      const expHT = qExpenses.reduce((a, c) => a + c.amountHT, 0);
      const tpsPaid = qExpenses.reduce((a, c) => a + c.tpsAmount, 0);
      const tvqPaid = qExpenses.reduce((a, c) => a + c.tvqAmount, 0);

      const expByCat = qExpenses.reduce((acc, curr) => {
        acc[curr.category] = (acc[curr.category] || 0) + curr.amountHT;
        return acc;
      }, {} as Record<string, number>);

      return {
        quarter: q,
        revHT,
        tpsColl,
        tvqColl,
        expHT,
        tpsPaid,
        tvqPaid,
        net: revHT - expHT,
        tpsNet: tpsColl - tpsPaid,
        tvqNet: tvqColl - tvqPaid,
        categories: expByCat
      };
    });
  }, [invoices, expenses, currentYear]);

  const annualTotals = useMemo(() => {
    return quarters.reduce((acc, q) => ({
      revHT: acc.revHT + q.revHT,
      tpsColl: acc.tpsColl + q.tpsColl,
      tvqColl: acc.tvqColl + q.tvqColl,
      expHT: acc.expHT + q.expHT,
      tpsPaid: acc.tpsPaid + q.tpsPaid,
      tvqPaid: acc.tvqPaid + q.tvqPaid,
      net: acc.net + q.net,
      tpsNet: acc.tpsNet + q.tpsNet,
      tvqNet: acc.tvqNet + q.tvqNet,
    }), {
      revHT: 0, tpsColl: 0, tvqColl: 0, expHT: 0, tpsPaid: 0, tvqPaid: 0, net: 0, tpsNet: 0, tvqNet: 0
    });
  }, [quarters]);

  return (
    <div className="space-y-8">
      <header className="flex flex-col md:flex-row justify-between md:items-end">
        <div>
          <h2 className="text-3xl font-black text-gray-900">Rapports Financiers {currentYear}</h2>
          <p className="text-gray-500 italic">Résumé consolidé pour le Québec et le Canada</p>
        </div>
        <div className="mt-4 md:mt-0 text-right">
          <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">Devise</p>
          <p className="text-lg font-bold text-gray-800">Dollar Canadien ($ CAD)</p>
        </div>
      </header>

      {/* Section Résumé Annuel */}
      <section className="bg-gradient-to-br from-indigo-900 to-indigo-800 rounded-3xl p-8 text-white shadow-xl border-4 border-indigo-700">
        <div className="flex justify-between items-center mb-8 border-b border-indigo-700 pb-4">
          <h3 className="text-2xl font-black flex items-center gap-2">
            <span className="text-3xl">📅</span> BILAN ANNUEL {currentYear}
          </h3>
          <div className="text-right">
            <p className="text-indigo-300 text-xs font-bold uppercase tracking-widest">État Global</p>
            <p className={`text-xl font-black ${annualTotals.net >= 0 ? 'text-green-400' : 'text-red-400'}`}>
              {annualTotals.net >= 0 ? 'PROFITABLE' : 'DÉFICITAIRE'}
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div className="space-y-1">
            <p className="text-indigo-300 text-xs font-bold uppercase">Chiffre d'Affaires HT</p>
            <p className="text-3xl font-black">{annualTotals.revHT.toLocaleString('fr-CA', { minimumFractionDigits: 2 })} $</p>
          </div>
          <div className="space-y-1">
            <p className="text-indigo-300 text-xs font-bold uppercase">Dépenses Totales HT</p>
            <p className="text-3xl font-black">{annualTotals.expHT.toLocaleString('fr-CA', { minimumFractionDigits: 2 })} $</p>
          </div>
          <div className="space-y-1">
            <p className="text-indigo-300 text-xs font-bold uppercase">Taxes à Remettre (Net)</p>
            <p className="text-3xl font-black">{(annualTotals.tpsNet + annualTotals.tvqNet).toLocaleString('fr-CA', { minimumFractionDigits: 2 })} $</p>
          </div>
          <div className="bg-white/10 p-4 rounded-2xl backdrop-blur-sm border border-white/10">
            <p className="text-indigo-200 text-xs font-bold uppercase mb-1">Bénéfice Net Global</p>
            <p className={`text-3xl font-black ${annualTotals.net >= 0 ? 'text-green-400' : 'text-red-400'}`}>
              {annualTotals.net.toLocaleString('fr-CA', { minimumFractionDigits: 2 })} $
            </p>
          </div>
        </div>
        
        <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-4">
           <div className="bg-indigo-950/50 p-4 rounded-xl border border-indigo-700">
             <h4 className="text-xs font-bold text-indigo-400 uppercase mb-2">Détail Taxes Annuel (Fédéral)</h4>
             <div className="flex justify-between"><span>TPS Collectée:</span> <span className="font-bold">+{annualTotals.tpsColl.toFixed(2)} $</span></div>
             <div className="flex justify-between"><span>TPS Payée (ITC):</span> <span className="font-bold text-red-400">-{annualTotals.tpsPaid.toFixed(2)} $</span></div>
           </div>
           <div className="bg-indigo-950/50 p-4 rounded-xl border border-indigo-700">
             <h4 className="text-xs font-bold text-indigo-400 uppercase mb-2">Détail Taxes Annuel (Québec)</h4>
             <div className="flex justify-between"><span>TVQ Collectée:</span> <span className="font-bold">+{annualTotals.tvqColl.toFixed(2)} $</span></div>
             <div className="flex justify-between"><span>TVQ Payée (ITR):</span> <span className="font-bold text-red-400">-{annualTotals.tvqPaid.toFixed(2)} $</span></div>
           </div>
        </div>
      </section>

      <div className="flex items-center gap-4">
        <div className="h-px bg-gray-200 flex-1"></div>
        <h3 className="text-gray-400 font-bold uppercase text-xs tracking-[0.2em]">Détails par Trimestre</h3>
        <div className="h-px bg-gray-200 flex-1"></div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
        {quarters.map((q) => (
          <div key={q.quarter} className="bg-white rounded-3xl shadow-sm border p-8 flex flex-col space-y-6">
            <div className="flex justify-between items-center border-b pb-4">
              <h3 className="text-2xl font-black text-indigo-900 italic">Trimestre {q.quarter}</h3>
              <div className="flex space-x-2">
                <span className={`px-4 py-1 rounded-full text-[10px] font-black uppercase ${q.net >= 0 ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                  {q.net >= 0 ? 'Profit' : 'Perte'}
                </span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-8">
              <div className="space-y-4">
                <h4 className="text-xs font-black text-gray-400 uppercase tracking-widest">Revenus & Ventes</h4>
                <div className="space-y-1">
                  <p className="text-sm text-gray-500">Chiffre d'Affaire (HT)</p>
                  <p className="text-xl font-bold">{q.revHT.toFixed(2)} $</p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm text-gray-500">TPS Collectée</p>
                  <p className="text-lg font-bold text-indigo-600">+{q.tpsColl.toFixed(2)} $</p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm text-gray-500">TVQ Collectée</p>
                  <p className="text-lg font-bold text-indigo-600">+{q.tvqColl.toFixed(2)} $</p>
                </div>
              </div>

              <div className="space-y-4 border-l pl-8">
                <h4 className="text-xs font-black text-gray-400 uppercase tracking-widest">Dépenses & Achats</h4>
                <div className="space-y-1">
                  <p className="text-sm text-gray-500">Dépenses (HT)</p>
                  <p className="text-xl font-bold">{q.expHT.toFixed(2)} $</p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm text-gray-500">ITC (TPS Payée)</p>
                  <p className="text-lg font-bold text-red-500">-{q.tpsPaid.toFixed(2)} $</p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm text-gray-500">ITR (TVQ Payée)</p>
                  <p className="text-lg font-bold text-red-500">-{q.tvqPaid.toFixed(2)} $</p>
                </div>
              </div>
            </div>

            <div className="bg-indigo-900 text-white p-6 rounded-2xl shadow-inner grid grid-cols-2 gap-4">
              <div className="border-r border-indigo-700 pr-4">
                <p className="text-[10px] font-bold text-indigo-300 uppercase">Net TPS à payer</p>
                <p className="text-2xl font-black">{q.tpsNet.toFixed(2)} $</p>
              </div>
              <div className="pl-4">
                <p className="text-[10px] font-bold text-indigo-300 uppercase">Net TVQ à payer</p>
                <p className="text-2xl font-black">{q.tvqNet.toFixed(2)} $</p>
              </div>
            </div>

            <div className="bg-gray-50 p-5 rounded-2xl border flex justify-between items-center">
              <span className="font-black text-gray-900 text-lg uppercase">Bénéfice Net (HT)</span>
              <span className={`text-2xl font-black ${q.net >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                {q.net.toFixed(2)} $
              </span>
            </div>

            <div>
              <h4 className="text-xs font-black text-gray-400 uppercase tracking-widest mb-4">Répartition par Catégorie</h4>
              <div className="grid grid-cols-2 gap-2">
                {Object.values(ExpenseCategory).map(cat => (
                  <div key={cat} className="flex justify-between items-center p-2 bg-gray-50 rounded text-sm">
                    <span className="text-gray-500">{cat}</span>
                    <span className="font-bold text-gray-800">{(q.categories[cat] || 0).toFixed(2)} $</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ReportsView;
