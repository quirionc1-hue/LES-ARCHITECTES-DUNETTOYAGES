
import React, { useState } from 'react';
import { Invoice, InvoiceItem } from '../types';

interface InvoicesViewProps {
  invoices: Invoice[];
  onAdd: (invoice: Invoice) => void;
  onDelete: (id: string) => void;
  businessName: string;
}

const InvoicesView: React.FC<InvoicesViewProps> = ({ invoices, onAdd, onDelete, businessName }) => {
  const [showForm, setShowForm] = useState(false);
  const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null);
  const [client, setClient] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [tpsRate] = useState(5.0);
  const [tvqRate] = useState(9.975);
  const [items, setItems] = useState<Omit<InvoiceItem, 'id'>[]>([{ description: '', quantity: 1, unitPrice: 0 }]);

  const handleAddItem = () => setItems([...items, { description: '', quantity: 1, unitPrice: 0 }]);
  const updateItem = (index: number, field: keyof Omit<InvoiceItem, 'id'>, value: any) => {
    const newItems = [...items];
    newItems[index] = { ...newItems[index], [field]: value };
    setItems(newItems);
  };

  const calculateTotals = () => {
    const totalHT = items.reduce((acc, item) => acc + (item.quantity * item.unitPrice), 0);
    const totalTPS = totalHT * (tpsRate / 100);
    const totalTVQ = totalHT * (tvqRate / 100);
    return { totalHT, totalTPS, totalTVQ, totalTTC: totalHT + totalTPS + totalTVQ };
  };

  const { totalHT, totalTPS, totalTVQ, totalTTC } = calculateTotals();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const newInvoice: Invoice = {
      id: crypto.randomUUID(),
      number: `FAC-${Date.now().toString().slice(-6)}`,
      date,
      clientName: client,
      items: items.map(i => ({ ...i, id: crypto.randomUUID() })),
      tpsRate,
      tvqRate,
      totalHT,
      totalTPS,
      totalTVQ,
      totalTTC
    };
    
    onAdd(newInvoice);
    setClient('');
    setItems([{ description: '', quantity: 1, unitPrice: 0 }]);
    setShowForm(false);
  };

  const handlePrint = (invoice: Invoice) => {
    setSelectedInvoice(invoice);
    // Timeout to ensure state update renders before print dialog
    setTimeout(() => {
      window.print();
    }, 100);
  };

  return (
    <div className="space-y-6">
      {/* View/Print Invoice Template (Hidden except during printing) */}
      {selectedInvoice && (
        <div className="hidden print:block fixed inset-0 bg-white p-12 z-50 overflow-visible">
          <div className="flex justify-between items-start border-b-2 border-slate-900 pb-8 mb-8">
            <div>
              <h1 className="text-4xl font-black text-slate-900 uppercase tracking-tighter">{businessName}</h1>
              <p className="text-slate-500 font-bold uppercase tracking-widest text-xs mt-2 italic">Facture de services</p>
            </div>
            <div className="text-right">
              <h2 className="text-2xl font-black text-slate-900">FACTURE</h2>
              <p className="text-slate-600 font-bold">N° {selectedInvoice.number}</p>
              <p className="text-slate-500 text-sm">Date: {new Date(selectedInvoice.date).toLocaleDateString('fr-CA')}</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-12 mb-12">
            <div>
              <h3 className="text-xs font-black text-slate-400 uppercase tracking-widest mb-2">Émetteur</h3>
              <p className="font-bold text-slate-900">{businessName}</p>
              <p className="text-sm text-slate-500">Québec, Canada</p>
            </div>
            <div className="text-right">
              <h3 className="text-xs font-black text-slate-400 uppercase tracking-widest mb-2">Facturé à</h3>
              <p className="font-bold text-slate-900 text-xl">{selectedInvoice.clientName}</p>
            </div>
          </div>

          <table className="w-full mb-12">
            <thead>
              <tr className="border-b-2 border-slate-900 text-left text-xs font-black uppercase tracking-widest">
                <th className="py-4">Description</th>
                <th className="py-4 text-center">Quantité</th>
                <th className="py-4 text-right">Prix Unit.</th>
                <th className="py-4 text-right">Montant HT</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {selectedInvoice.items.map((item) => (
                <tr key={item.id}>
                  <td className="py-4 font-bold text-slate-800">{item.description}</td>
                  <td className="py-4 text-center">{item.quantity}</td>
                  <td className="py-4 text-right">{item.unitPrice.toFixed(2)} $</td>
                  <td className="py-4 text-right font-bold">{(item.quantity * item.unitPrice).toFixed(2)} $</td>
                </tr>
              ))}
            </tbody>
          </table>

          <div className="flex justify-end">
            <div className="w-80 space-y-2">
              <div className="flex justify-between text-slate-600">
                <span>Sous-total HT</span>
                <span className="font-bold">{selectedInvoice.totalHT.toFixed(2)} $</span>
              </div>
              <div className="flex justify-between text-indigo-600">
                <span>TPS (5.0%)</span>
                <span className="font-bold">+{selectedInvoice.totalTPS.toFixed(2)} $</span>
              </div>
              <div className="flex justify-between text-indigo-600">
                <span>TVQ (9.975%)</span>
                <span className="font-bold">+{selectedInvoice.totalTVQ.toFixed(2)} $</span>
              </div>
              <div className="flex justify-between text-2xl font-black text-slate-900 pt-4 border-t-2 border-slate-900">
                <span>Total TTC</span>
                <span>{selectedInvoice.totalTTC.toFixed(2)} $</span>
              </div>
            </div>
          </div>

          <div className="mt-24 border-t pt-8 text-center text-slate-400 text-xs italic">
            Merci de votre confiance. <br />
            {businessName} - Membre Pro Québec
          </div>
        </div>
      )}

      {/* Standard Screen View */}
      <div className="print:hidden space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Factures (Ventes)</h2>
            <p className="text-sm text-gray-500">Gérez vos revenus pour <span className="font-bold text-indigo-600">{businessName}</span></p>
          </div>
          <button
            onClick={() => setShowForm(!showForm)}
            className="bg-indigo-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-indigo-700 transition-colors shadow-lg"
          >
            {showForm ? 'Annuler' : '+ Créer une Facture'}
          </button>
        </div>

        {showForm && (
          <form onSubmit={handleSubmit} className="bg-white p-6 rounded-xl shadow-md border border-indigo-100 space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">Client</label>
                <input
                  type="text"
                  required
                  value={client}
                  onChange={(e) => setClient(e.target.value)}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm p-2 border focus:ring-2 focus:ring-indigo-500"
                  placeholder="Ex: Services Tech Montréal"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Date de facturation</label>
                <input
                  type="date"
                  required
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm p-2 border focus:ring-2 focus:ring-indigo-500"
                />
              </div>
            </div>

            <div className="space-y-2">
              <h3 className="text-sm font-bold uppercase text-gray-400 tracking-widest pt-4">Articles / Services (Hors Taxes)</h3>
              <div className="hidden md:grid grid-cols-4 gap-2 text-xs font-bold text-gray-500 px-1">
                <div className="col-span-2">Description</div>
                <div>Quantité</div>
                <div>Prix Unitaire ($)</div>
              </div>
              {items.map((item, index) => (
                <div key={index} className="grid grid-cols-1 md:grid-cols-4 gap-2">
                  <input
                    type="text"
                    placeholder="Ex: Développement Web"
                    className="md:col-span-2 p-2 border rounded focus:ring-1 focus:ring-indigo-300"
                    value={item.description}
                    onChange={(e) => updateItem(index, 'description', e.target.value)}
                    required
                  />
                  <input
                    type="number"
                    min="1"
                    className="p-2 border rounded focus:ring-1 focus:ring-indigo-300"
                    value={item.quantity}
                    onChange={(e) => updateItem(index, 'quantity', Number(e.target.value))}
                    required
                  />
                  <input
                    type="number"
                    step="0.01"
                    className="p-2 border rounded focus:ring-1 focus:ring-indigo-300"
                    value={item.unitPrice}
                    onChange={(e) => updateItem(index, 'unitPrice', Number(e.target.value))}
                    required
                  />
                </div>
              ))}
              <button
                type="button"
                onClick={handleAddItem}
                className="bg-gray-50 text-indigo-600 px-3 py-1 rounded text-sm font-bold mt-2 hover:bg-gray-100 border border-indigo-100"
              >
                + Ajouter une ligne
              </button>
            </div>

            <div className="pt-6 border-t flex flex-col items-end space-y-2">
              <div className="flex justify-between w-64 text-sm">
                <span className="text-gray-500">Sous-total (HT)</span>
                <span>{totalHT.toFixed(2)} $</span>
              </div>
              <div className="flex justify-between w-64 text-sm">
                <span className="text-gray-500">TPS (5.0%)</span>
                <span className="text-indigo-600">+{totalTPS.toFixed(2)} $</span>
              </div>
              <div className="flex justify-between w-64 text-sm">
                <span className="text-gray-500">TVQ (9.975%)</span>
                <span className="text-indigo-600">+{totalTVQ.toFixed(2)} $</span>
              </div>
              <div className="flex justify-between w-64 text-xl font-black pt-2 border-t">
                <span>Total (TTC)</span>
                <span className="text-indigo-900">{totalTTC.toFixed(2)} $</span>
              </div>
              <button type="submit" className="mt-4 bg-indigo-600 text-white px-8 py-3 rounded-xl font-bold shadow-lg hover:bg-indigo-700">
                Enregistrer la Facture
              </button>
            </div>
          </form>
        )}

        <div className="bg-white rounded-xl shadow-sm border overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-400 uppercase">Date</th>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-400 uppercase">Client</th>
                <th className="px-6 py-3 text-right text-xs font-bold text-gray-400 uppercase">Total TTC</th>
                <th className="px-6 py-3 text-center text-xs font-bold text-gray-400 uppercase">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {invoices.length === 0 && (
                <tr>
                  <td colSpan={4} className="px-6 py-10 text-center text-gray-400 italic">Aucune transaction de vente enregistrée.</td>
                </tr>
              )}
              {invoices.map((inv) => (
                <tr key={inv.id} className="hover:bg-gray-50 transition-colors group">
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{new Date(inv.date).toLocaleDateString('fr-CA')}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-bold text-gray-900">{inv.clientName}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-right font-black text-indigo-900">{inv.totalTTC.toFixed(2)} $</td>
                  <td className="px-6 py-4 whitespace-nowrap text-center space-x-2">
                    <button 
                      onClick={() => handlePrint(inv)} 
                      className="text-indigo-600 hover:text-indigo-800 p-2 rounded hover:bg-indigo-50 font-bold text-xs uppercase"
                    >
                      Imprimer / PDF
                    </button>
                    <button onClick={() => onDelete(inv.id)} className="text-red-400 hover:text-red-600 p-2 rounded hover:bg-red-50">
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default InvoicesView;
