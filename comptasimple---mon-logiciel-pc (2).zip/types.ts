
export enum ExpenseCategory {
  OFFICE = 'Dépenses Bureau',
  SUPPLIES = 'Fournitures',
  SUPPLIES_NO_TAX = 'Fournitures (Sans Taxe)',
  AUTOMOBILE = 'Automobile',
  OTHER = 'Autres'
}

export enum AssetType {
  AUTO = 'Véhicule (Cat. 10 - 30%)',
  EQUIPMENT = 'Équipement (Cat. 8 - 20%)',
  COMPUTER = 'Informatique (Cat. 50 - 55%)'
}

export interface Asset {
  id: string;
  name: string;
  type: AssetType;
  purchaseDate: string;
  cost: number;
  openingUCC: number; // FNACC - Fraction non amortie du coût en capital (An passé)
  additions: number;
  disposals: number;
  ccaRate: number; // Taux de DPA
}

export interface InvoiceItem {
  id: string;
  description: string;
  quantity: number;
  unitPrice: number;
}

export interface Invoice {
  id: string;
  number: string;
  date: string;
  clientName: string;
  items: InvoiceItem[];
  tpsRate: number;
  tvqRate: number;
  totalHT: number;
  totalTPS: number;
  totalTVQ: number;
  totalTTC: number;
}

export interface Expense {
  id: string;
  date: string;
  description: string;
  amountHT: number;
  tpsAmount: number;
  tvqAmount: number;
  totalTTC: number;
  category: ExpenseCategory;
}

export type View = 'dashboard' | 'invoices' | 'expenses' | 'reports' | 'amortization' | 'settings' | 'journal';

export interface QuarterlySummary {
  quarter: number;
  year: number;
  revenueHT: number;
  tpsCollected: number;
  tvqCollected: number;
  expensesHT: number;
  tpsPaid: number;
  tvqPaid: number;
  netIncome: number;
  expensesByCategory: Record<ExpenseCategory, number>;
}
