
import React, { useState, useEffect } from 'react';
import { View, Invoice, Expense, Asset } from './types';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import InvoicesView from './components/InvoicesView';
import ExpensesView from './components/ExpensesView';
import ReportsView from './components/ReportsView';
import AmortizationView from './components/AmortizationView';
import SettingsView from './components/SettingsView';
import JournalView from './components/JournalView';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<View>('dashboard');
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  
  const [businessName, setBusinessName] = useState<string>(() => {
    return localStorage.getItem('cs_business_name') || 'Mon Entreprise';
  });

  const [invoices, setInvoices] = useState<Invoice[]>(() => {
    const saved = localStorage.getItem('cs_invoices');
    return saved ? JSON.parse(saved) : [];
  });
  
  const [expenses, setExpenses] = useState<Expense[]>(() => {
    const saved = localStorage.getItem('cs_expenses');
    return saved ? JSON.parse(saved) : [];
  });

  const [assets, setAssets] = useState<Asset[]>(() => {
    const saved = localStorage.getItem('cs_assets');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem('cs_business_name', businessName);
  }, [businessName]);

  useEffect(() => {
    localStorage.setItem('cs_invoices', JSON.stringify(invoices));
  }, [invoices]);

  useEffect(() => {
    localStorage.setItem('cs_expenses', JSON.stringify(expenses));
  }, [expenses]);

  useEffect(() => {
    localStorage.setItem('cs_assets', JSON.stringify(assets));
  }, [assets]);

  // Détection de la possibilité d'installer l'app sur le PC
  useEffect(() => {
    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      setDeferredPrompt(e);
    });
  }, []);

  const handleInstall = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') {
        setDeferredPrompt(null);
      }
    } else {
      alert("Pour installer sur PC : Cliquez sur l'icône 'Installer' dans la barre d'adresse de votre navigateur (en haut à droite).");
    }
  };

  const addInvoice = (invoice: Invoice) => setInvoices([invoice, ...invoices]);
  const addExpense = (expense: Expense) => setExpenses([expense, ...expenses]);
  const deleteInvoice = (id: string) => setInvoices(invoices.filter(i => i.id !== id));
  const deleteExpense = (id: string) => setExpenses(expenses.filter(e => e.id !== id));
  
  const saveAssets = (newAssets: Asset[]) => setAssets(newAssets);

  const importData = (data: { businessName: string, invoices: Invoice[], expenses: Expense[], assets: Asset[] }) => {
    if (data.businessName) setBusinessName(data.businessName);
    if (data.invoices) setInvoices(data.invoices);
    if (data.expenses) setExpenses(data.expenses);
    if (data.assets) setAssets(data.assets);
    alert("Données importées avec succès !");
  };

  const renderView = () => {
    switch (currentView) {
      case 'dashboard':
        return <Dashboard invoices={invoices} expenses={expenses} />;
      case 'invoices':
        return <InvoicesView invoices={invoices} onAdd={addInvoice} onDelete={deleteInvoice} businessName={businessName} />;
      case 'expenses':
        return <ExpensesView expenses={expenses} onAdd={addExpense} onDelete={deleteExpense} />;
      case 'reports':
        return <ReportsView invoices={invoices} expenses={expenses} />;
      case 'amortization':
        return <AmortizationView assets={assets} onSave={saveAssets} />;
      case 'journal':
        return <JournalView invoices={invoices} expenses={expenses} onDeleteInvoice={deleteInvoice} onDeleteExpense={deleteExpense} />;
      case 'settings':
        return (
          <SettingsView 
            businessName={businessName} 
            setBusinessName={setBusinessName} 
            data={{ businessName, invoices, expenses, assets }} 
            onImport={importData}
            onInstall={handleInstall}
            canInstall={!!deferredPrompt}
          />
        );
      default:
        return <Dashboard invoices={invoices} expenses={expenses} />;
    }
  };

  return (
    <div className="flex min-h-screen bg-gray-50 font-sans print:bg-white">
      <div className="print:hidden">
        <Sidebar 
          currentView={currentView} 
          setView={setCurrentView} 
          businessName={businessName} 
          setBusinessName={setBusinessName} 
        />
      </div>
      <main className="flex-1 p-4 md:p-8 overflow-y-auto print:p-0 print:overflow-visible">
        <div className="max-w-7xl mx-auto">
          {renderView()}
        </div>
      </main>
    </div>
  );
};

export default App;
